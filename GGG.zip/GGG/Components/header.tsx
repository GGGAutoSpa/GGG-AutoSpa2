'use client';
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      style={{
        position: "fixed",
        top: 0,
        width: "100%",
        padding: scrolled ? "10px 20px" : "20px 20px",
        background: scrolled ? "rgba(0,0,0,0.8)" : "transparent",
        backdropFilter: "blur(10px)",
        transition: "0.3s",
        color: "white",
        zIndex: 1000
      }}
    >
      <h2>GGG AutoSpa</h2>
    </header>
  );
};

export default Header;