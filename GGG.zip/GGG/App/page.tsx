import Header from '../components/Header';

export default function Home() {
  return (
    <main style={{ background: '#000', color: '#fff', minHeight: '100vh' }}>
      <Header />

      <div style={{ padding: '100px', textAlign: 'center' }}>
        <h1>GGG AutoSpa</h1>
        <p>Premium Car Detailing Sydney</p>
      </div>
    </main>
  );
}